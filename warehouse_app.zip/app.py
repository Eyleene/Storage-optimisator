import sqlite3
from flask import Flask, g, jsonify, request, send_from_directory

DATABASE = 'data.db'
app = Flask(__name__, static_folder='static')

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/products', methods=['GET', 'POST'])
def products():
    db = get_db()
    if request.method == 'GET':
        cur = db.execute('SELECT * FROM products')
        items = [dict(row) for row in cur.fetchall()]
        return jsonify(items)
    else:
        data = request.get_json()
        db.execute('INSERT INTO products (name, quantity) VALUES (?, ?)', (data['name'], data['quantity']))
        db.commit()
        return jsonify({'status':'ok'})

@app.route('/api/products/<int:id>', methods=['PUT','DELETE'])
def product_modify(id):
    db = get_db()
    if request.method == 'PUT':
        data = request.get_json()
        db.execute('UPDATE products SET name=?, quantity=? WHERE id=?', (data['name'], data['quantity'], id))
        db.commit()
        return jsonify({'status':'ok'})
    else:
        db.execute('DELETE FROM products WHERE id=?', (id,))
        db.commit()
        return jsonify({'status':'ok'})

if __name__ == '__main__':
    # Ініціалізація бази
    conn = sqlite3.connect(DATABASE)
    conn.execute('CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, quantity INTEGER)')
    conn.close()
    app.run(debug=True)
