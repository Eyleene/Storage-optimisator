async function api(path, method='GET', body=null){
    const opts = {method, headers:{'Content-Type':'application/json'}};
    if(body) opts.body = JSON.stringify(body);
    const res = await fetch('/api/products' + (path||''), opts);
    return res.json();
}

async function loadProducts(){
    const products = await api('');
    const list = document.getElementById('product-list');
    list.innerHTML='';
    products.forEach(p=>{
        const li=document.createElement('li');
        li.textContent=`${p.name} - ${p.quantity}`;
        list.appendChild(li);
    });
}

async function addProduct(){
    const name=document.getElementById('name').value;
    const quantity=parseInt(document.getElementById('quantity').value);
    await api('', 'POST', {name, quantity});
    loadProducts();
}

loadProducts();
